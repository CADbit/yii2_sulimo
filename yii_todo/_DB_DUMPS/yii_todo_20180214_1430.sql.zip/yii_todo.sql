--
-- Baza danych: `yii_todo`
--
CREATE DATABASE IF NOT EXISTS `yii_todo` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `yii_todo`;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `datefrom` date DEFAULT NULL,
  `dateto` date DEFAULT NULL,
  `timefrom` time DEFAULT NULL,
  `timeto` time DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL,
  `idtype` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `task`
--

INSERT INTO `task` (`id`, `description`, `datefrom`, `dateto`, `timefrom`, `timeto`, `state`, `idtype`) VALUES
(1, 'Szkolenie Yii', '2018-02-19', '2018-02-19', '10:00:00', '11:00:00', 0, 4),
(2, 'Szkolenie JS', '2018-02-22', '2018-02-22', '12:00:00', '14:00:00', 0, 4),
(3, 'Poprawić wygenerowany kod do widoków tabelek', '2018-02-15', '2018-02-15', '08:00:00', '16:00:00', 0, 5),
(4, 'Ala ma kota', '2018-02-15', '2018-02-15', '18:00:00', '19:00:00', 0, 3),
(5, 'To koniec', '2018-02-15', '2018-02-15', '08:00:00', '16:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `type`
--

CREATE TABLE `type` (
  `id` tinyint(4) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `type`
--

INSERT INTO `type` (`id`, `name`) VALUES
(1, 'Zadanie'),
(2, 'Spotkanie'),
(3, 'Kolacja'),
(4, 'Szkolenie'),
(5, 'Inne');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_task_type_idx` (`idtype`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT dla tabeli `type`
--
ALTER TABLE `type`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `task`
--
ALTER TABLE `task`
  ADD CONSTRAINT `fk_task_type` FOREIGN KEY (`idtype`) REFERENCES `type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
